import {$} from './libs';



window.jQuery = window.$ = $;
